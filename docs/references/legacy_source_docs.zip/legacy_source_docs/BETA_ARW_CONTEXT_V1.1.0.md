# WRF Config Studio v1.1.0-beta-arw-context ARW Context Beta

Generated: 2026-05-02T05:23:29Z

## Status

This is a separate next-generation beta package. The **v1.0.0 online-only consolidated-docs build remains the mainline**.

## What this beta adds

This beta incorporates NCAR/TN-556+STR, *A Description of the Advanced Research WRF Model Version 4*, as a scientific-context source for the `namelist.input` editor.

Added files:

```text
docs/references/v4_technote.pdf
data/runtime/namelist.arw_technical_note_context.json
```

## Editor behavior

The Documentation tab can now show an **ARW Technical Note scientific context** block when a selected variable maps to ARW topics such as:

- temporal discretization
- stability constraints
- hybrid vertical coordinate
- map projections
- turbulent mixing and filters
- initialization
- lateral boundary conditions
- nesting
- physics
- stochastic parameterization
- nudging
- WRFDA / data assimilation

The editor also displays small topic badges next to mapped variables in the Editor tab.

## Policy

This beta is **reference-only**.

It does not:

- block saves,
- auto-fix values,
- hide variables,
- enforce compatibility,
- change v1.0.0 export behavior,
- change the OBSPROC split,
- change WRFDA placement in `namelist.input`.

## Mainline separation

Keep this beta separate from v1.0.0 mainline while testing the next-generation documentation and metadata approach.
