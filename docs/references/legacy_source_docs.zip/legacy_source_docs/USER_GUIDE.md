# WRF Config Studio User Guide

Version: **v1.0.0**  
Generated: 2026-05-02T04:52:05Z

WRF Config Studio is a browser-based configuration environment for designing WRF domains, editing `namelist.wps` and `namelist.input`, exporting OBSPROC configuration as `namelist.obsproc`, and exploring WRF, WRFDA, OBSPROC, and Registry metadata.

This guide describes the current **WRF Config Studio v1.0.0** build, including the OBSPROC export split.

---

## Table of Contents

1. [Overview](#1-overview)
2. [Supported Platforms and Browsers](#2-supported-platforms-and-browsers)
3. [Launching the Application](#3-launching-the-application)
4. [Application Layout](#4-application-layout)
5. [Map and Domain Editor](#5-map-and-domain-editor)
6. [`namelist.wps` Workflow](#6-namelistwps-workflow)
7. [`namelist.input` Editor](#7-namelistinput-editor)
8. [WRFDA Support](#8-wrfda-support)
9. [OBSPROC Support](#9-obsproc-support)
10. [Save, Copy, and Export Behavior](#10-save-copy-and-export-behavior)
11. [Suggestions, Defaults, and User Control](#11-suggestions-defaults-and-user-control)
12. [Documentation Tab](#12-documentation-tab)
13. [Recommended Workflow](#13-recommended-workflow)
14. [Troubleshooting](#14-troubleshooting)
15. [Known Limitations](#15-known-limitations)
16. [Credits and Original Project](#16-credits-and-original-project)

---

## 1. Overview

WRF Config Studio helps users prepare WRF-related configuration files through a visual, browser-based interface.

It supports:

- Interactive WRF domain creation and editing
- `namelist.wps` generation
- full-catalog `namelist.input` editing
- WRFDA namelist groups inside `namelist.input`
- OBSPROC record editing and separate `namelist.obsproc` export
- Registry metadata review
- required-field warnings
- suggested starting values for common WRF timing fields
- full 360-degree map and graticule behavior
- desktop touch-screen and trackpad interaction improvements

The project was formerly built as WRF Domain Wizard and has been rebranded as **WRF Config Studio v1.0.0**.

---

## 2. Supported Platforms and Browsers

WRF Config Studio is designed for desktop browser use.

### Windows

Supported desktop browsers:

- Google Chrome
- Microsoft Edge
- Mozilla Firefox

### macOS

Supported desktop browsers:

- Safari
- Google Chrome
- Mozilla Firefox

### Linux

Supported desktop browsers:

- Google Chrome / Chromium
- Mozilla Firefox
- Microsoft Edge

### Mobile and tablet devices

Mobile phone and tablet layouts are not release targets for v1.0.0.

Desktop touch screens and trackpads are supported through improved pointer, touch, and gesture handling, but mobile layouts are not considered supported.

---

## 3. Launching the Application

WRF Config Studio should be launched through a local HTTP server.

Do **not** rely on opening `index.html` directly with `file://`, because browser security rules can block local JSON files, examples, metadata catalogs, and other runtime assets.

### Option A: Python local server

From the extracted application folder, run:

```bash
python -m http.server 8000
```

Then open:

```text
http://127.0.0.1:8000
```

### Option B: Included launcher scripts

The package includes helper launchers:

```text
START_LOCAL_SERVER.bat
START_LOCAL_SERVER.sh
START_LOCAL_SERVER.command
launch_local_server.py
```

Use the one that matches your operating system.

### Clearing browser cache after local updates

When testing a rebuilt package locally, use a hard refresh after replacing files.

Common shortcuts:

```text
Windows/Linux Chrome, Edge, Firefox: Ctrl+F5
macOS Chrome/Firefox: Cmd+Shift+R
macOS Safari: Option+Cmd+E, then reload
```

This helps avoid stale JavaScript, CSS, and runtime catalog files being reused from browser cache.

---

## 4. Application Layout

The interface is organized around a map and a left-side tool panel.

Main areas:

- **Map view**: visual WRF domain design
- **Domains panel**: projection, grid, nesting, WPS fields, and domain controls
- **Domain Intelligence panel**: projection and nest helper actions
- **Geographic files panel**: geographic file and reference workflows
- **Settings/About panels**: app information, credits, and reference links
- **`namelist.input` modal**: full metadata-driven editor with Editor, Text, and Documentation tabs

The footer includes utility buttons such as Save, Copy, Close, and error-log tools depending on the active dialog or panel.

---

## 5. Map and Domain Editor

The map is used to create, position, resize, and inspect WRF domains.

### Map behavior

WRF Config Studio includes:

- full 360-degree map display behavior
- repeating graticule lines
- domain wrapping across world copies
- canonical longitude export values
- display-only adjacent world-copy domain polygons

This means the map can visually repeat across the dateline while exported WPS values remain normalized and usable.

### Map latitude limit

The visible map is constrained to approximately:

```text
-85° to +85° latitude
```

This is a Web Mercator display limitation. It does not mean WRF calculations are capped in the same way, and it does not change exported `namelist.wps` or `namelist.input` values.

### Creating a new domain

1. Open the **Domains** panel.
2. Choose or confirm the map projection.
3. Click **New**.
4. Click and drag on the map to draw the parent domain.
5. Release to finish drawing.
6. Review the generated grid and projection values in the Domains panel.

### Moving a domain

To move a domain:

1. Select the domain on the map.
2. Drag the domain body or center marker depending on projection and editing mode.
3. Review updated `ref_lat`, `ref_lon`, and related projection parameters.

For wrapped map views, the domain may visually shift into the active visible world copy. Exported longitudes remain canonical.

### Resizing a domain

Resize handles appear around editable domains.

Use the corner or edge handles to adjust:

- `e_we`
- `e_sn`
- `i_parent_start`
- `j_parent_start`

For nested domains, resizing remains constrained by parent-domain placement and nesting rules.

### Domain Intelligence panel

The Domain Intelligence panel provides helper actions:

- **Auto-fill projection**
- **Snap nest values**
- **Suggest projection**
- **Update**
- Lambert parallels mode selection

Lambert parallels mode controls how `truelat1` and `truelat2` are suggested for Lambert domains.

Available modes:

| Mode | Behavior |
|---|---|
| Legacy | `truelat1 = ref_lat`; `truelat2 = ref_lat ± 15` by hemisphere |
| Domain-optimized | brackets the center latitude to reduce local distortion |
| WRF standard | uses `truelat1 = 30`, `truelat2 = 60` |

In the current build, changing Lambert parallels mode and pressing **Update** applies the selected mode to `truelat1` and `truelat2` before the domain redraws.

---

## 6. `namelist.wps` Workflow

The WPS workflow controls domain geometry, projection settings, timing, and geographic input settings.

Common WPS fields include:

- `map_proj`
- `ref_lat`
- `ref_lon`
- `stand_lon`
- `truelat1`
- `truelat2`
- `dx`
- `dy`
- `max_dom`
- `e_we`
- `e_sn`
- `parent_grid_ratio`
- `i_parent_start`
- `j_parent_start`
- `geog_data_path`

### Opening an existing `namelist.wps`

Use the **Open** button in the Domains panel to load an existing `namelist.wps`.

After loading, the map and WPS fields update from the file.

### Editing WPS values

You can edit WPS fields directly in the sidebar.

After manual edits, use **Update** to apply changes to the map.

### Projection notes

Projection support includes common WRF regional projections such as:

- Lambert
- Mercator
- Polar
- Lat-lon

For Lambert, `dx` and `dy` should be in meters.

### Exporting `namelist.wps`

Use the WPS save/export dialog to download or copy the current `namelist.wps`.

---

## 7. `namelist.input` Editor

The `namelist.input` editor is a full-catalog, metadata-driven editor.

Open it from the **namelist.input** button in the Domains panel.

The editor includes three primary tabs:

- **Editor**
- **Text**
- **Documentation**

### Full catalog behavior

In v1.0.0:

- all catalog variables are visible
- no UI filtering is applied
- previous hidden or advanced status is preserved only as reference metadata
- compatibility validation is inactive and reference-only
- dependency hints are metadata only

### Editor tab

The Editor tab shows namelist groups and variables.

The group list includes core WRF groups, WRFDA groups, OBSPROC records, and registry-derived groups.

Examples:

```text
&time_control
&domains
&physics
&dynamics
&bdy_control
&wrfvar1
&wrfvar2
&wrfvar14
&obsproc_record1
&obsproc_record2
```

### Text tab

The Text tab previews the generated **`namelist.input`** content.

Important: OBSPROC records are not included in the `namelist.input` preview because they are exported separately as `namelist.obsproc`.

### Documentation tab

The Documentation tab shows documentation sources and field-level metadata.

It includes links such as:

- WRF Users Guide: namelist variables
- WRF Registry files
- `run/README.namelist`
- WRF Best Practices for WPS
- WRF Best Practices for WRF

Selecting a variable in the editor displays merged documentation, defaults, source references, and option metadata when available.

---

## 8. WRFDA Support

WRFDA uses **`namelist.input`**.

WRFDA groups remain in `namelist.input` when saved or copied.

Examples:

```text
&wrfvar1
&wrfvar2
&wrfvar3
&wrfvar14
&wrfvar21
&wrfvar22
```

WRFDA-related support groups also remain in `namelist.input`, such as:

```text
&obs_opt
&radar_da
&perturbation
&wrf_cmaq
```

The WRFDA editor support is intentionally metadata-focused. The app does not enforce WRFDA compatibility rules, and it does not replace WRFDA runtime validation.

---

## 9. OBSPROC Support

OBSPROC uses a separate file named:

```text
namelist.obsproc
```

The editor exposes OBSPROC groups for convenience as:

```text
&obsproc_record1
&obsproc_record2
&obsproc_record3
&obsproc_record4
&obsproc_record5
&obsproc_record6
&obsproc_record7
&obsproc_record8
&obsproc_record9
```

The `obsproc_` prefix avoids collisions with WRF, WRFDA, and registry group names inside the combined editor.

### OBSPROC export conversion

When exporting `namelist.obsproc`, WRF Config Studio converts the UI group names back to real OBSPROC record names:

```text
&obsproc_record1  →  &record1
&obsproc_record2  →  &record2
&obsproc_record3  →  &record3
...
&obsproc_record9  →  &record9
```

### OBSPROC is excluded from `namelist.input`

OBSPROC record groups are **not** written to `namelist.input`.

They are saved separately as `namelist.obsproc`.

---

## 10. Save, Copy, and Export Behavior

WRF Config Studio supports separate and combined export workflows.

### `namelist.wps`

The WPS export is generated from the map and WPS sidebar state.

Output file:

```text
namelist.wps
```

### `namelist.input`

The `namelist.input` export includes:

- WRF core groups
- WRFDA `&wrfvar*` groups
- WRFDA-related support groups
- registry-derived non-OBSPROC groups selected in the editor

It excludes:

```text
&obsproc_record*
```

Output file:

```text
namelist.input
```

### `namelist.obsproc`

The `namelist.obsproc` export includes only OBSPROC records.

It converts editor group names from `&obsproc_record*` to `&record*`.

Output file:

```text
namelist.obsproc
```

### Save options

The current editor supports these save paths:

```text
Save namelist.input
Save namelist.obsproc
Save both
```

### Copy options

The current editor supports copying generated `namelist.input` text.

### Save both

The **Save both** option exports both:

```text
namelist.input
namelist.obsproc
```

Depending on browser behavior, this may save both files individually or package them together.

### Export formatting rules

Export behavior:

- blank array entries are omitted rather than written as malformed comma-only values
- valid zero values export normally
- valid false logical values export normally
- missing required fields trigger a warning, not a hard block

---

## 11. Suggestions, Defaults, and User Control

WRF Config Studio follows a user-control-first philosophy.

### The editor may suggest values

Suggested values are starting points. They are not locks.

Current suggestions include:

| Field area | Suggestion behavior |
|---|---|
| `domains.time_step` | suggested from parent-grid spacing, commonly using `6 × dx_km` as a starting value |
| `physics.radt` | suggested from innermost active grid spacing, using roughly 1 minute per km |
| `time_control.run_*` | suggested from WPS start and end times |
| `physics.cudt` | suggested when applicable in editor state |

### Manual edits are preserved

Once a user manually edits a suggested value, the tool should preserve that manual value rather than repeatedly overriding it.

### Required-field warnings

Some fields may be required for a complete or useful WRF configuration.

When required selected fields are blank:

- the app warns before save/export
- the user may cancel and return to the editor
- the user may continue intentionally

The app does not silently fill required physics selections such as blank scheme choices.

### Compatibility metadata

Compatibility data may exist in the catalog, but v1.0.0 does not enforce it.

The UI does not:

- block saves based on compatibility rules
- auto-fix physics selections
- hide variables based on compatibility logic
- force dependency decisions

Compatibility information is reference-only.

---

## 12. Documentation Tab

The Documentation tab is intended to give users context while editing.

It supports:

- general WRF documentation links
- registry references
- README references
- best-practice links
- selected-variable metadata display

When a variable is selected, the documentation panel may show:

- variable name
- group
- default value
- type
- source priority
- registry metadata
- dependency hints
- notes or best-practice guidance

The Documentation tab is informational. It does not enforce choices.

---

## 13. Recommended Workflow

A typical workflow:

1. Launch the app through a local HTTP server.
2. Confirm the browser tab shows **WRF Config Studio v1.0.0**.
3. Open the **Domains** panel.
4. Choose a map projection.
5. Create the parent domain, `d01`.
6. Adjust domain size, grid spacing, and projection fields.
7. Add nested domains if needed.
8. Use **Auto-fill projection**, **Snap nest values**, or **Update** if helpful.
9. Save or copy `namelist.wps`.
10. Open the `namelist.input` editor.
11. Review required fields and suggested values.
12. Search for needed variables or expand groups manually.
13. Review WRFDA groups if your workflow uses WRFDA.
14. Review OBSPROC records if your workflow uses OBSPROC.
15. Open the Text tab to review generated `namelist.input`.
16. Save `namelist.input`.
17. Save `namelist.obsproc` if OBSPROC records are needed.
18. Use **Save both** when both files are needed.
19. Run WRF/WPS/WRFDA/OBSPROC validation outside the tool before production use.

---

## 14. Troubleshooting

### The browser still shows an older version

Use a hard refresh.

```text
Ctrl+F5
```

If that does not work, clear browser cache for `127.0.0.1`.

### The app does not load local JSON files

Launch through a local HTTP server instead of opening `index.html` directly.

Recommended:

```bash
python -m http.server 8000
```

### Map tiles do not load

Check internet access.

The map now uses online tile providers only. Check internet access and try another map layer from the layer selector. If online tiles are unavailable, the map background may not render until a network connection or selected tile provider is available.

### The domain does not appear where expected after dateline panning

The map repeats world copies visually. The editable domain is shifted into the visible world copy for display, while export longitudes remain canonical.

### Longitude fields turn red

Longitude fields should remain in canonical range for WPS/editor values.

If a wrapped display longitude appears in a field, hard refresh the browser and confirm you are running the latest v1.0.0 build.

### Lambert parallels mode does not seem to apply

Use the latest v1.0.0 build.

Changing Lambert parallels mode and pressing **Update** should apply the selected mode to `truelat1` and `truelat2` before the domain redraws.

### Touch screen or trackpad gestures feel difficult

Use the latest v1.0.0 build with touch/trackpad fixes.

The build includes pointer and touch handling for:

- map navigation
- new-domain drawing
- domain dragging
- resize handles

### OBSPROC records are missing from `namelist.input`

That is expected.

OBSPROC records are exported separately as:

```text
namelist.obsproc
```

### WRFDA groups are still in `namelist.input`

That is expected.

WRFDA uses `namelist.input`, so `&wrfvar*` groups remain there.

### The editor is too large to browse manually

Use search. The full catalog intentionally exposes all variables.

### Missing required values warning appears

This means selected fields needed for a clean export are still blank.

Options:

- cancel and fill the values
- continue intentionally and export a partial file

### Compatibility warnings are not shown

That is expected. Compatibility validation is inactive in v1.0.0.

---

## 15. Known Limitations

- Mobile phone and tablet layouts are not supported as a release target.
- Direct `file://` launch is not recommended.
- The map display is limited to approximately `-85°` to `+85°` latitude.
- Compatibility metadata is reference-only and does not validate a full WRF run.
- The tool does not replace WRF, WPS, WRFDA, or OBSPROC runtime validation.
- Generated files should always be reviewed before production use.
- Historical source file names may still include the legacy WRF Domain Wizard name for compatibility.

---

## 16. Credits and Original Project
## NOAA/FSL WRF SI GUI Lineage

WRF Config Studio also acknowledges the earlier NOAA Forecast Systems Laboratory / Forecast Systems Laboratory (FSL) WRF Standard Initialization GUI work by Paula T. McCaslin, John R. Smart, Brent Shaw, and Brian D. Jamison.

That NOAA/FSL GUI helped users define and localize WRF grids, prepare static surface characteristics, process initial and lateral boundary-condition data, and create display graphics. It demonstrated graphical workflow concepts that later WRF domain tools built upon, including map-based domain selection, projection controls, grid-value editing, validation feedback, workflow panels, and user guidance.

The historical reference PDF is included at:

```text
docs/references/WRF_GUI_original_source_69852.pdf
```


WRF Config Studio is built upon the original WRF Domain Wizard developed by **Jiří Richter**.

His work provided the foundation and first-generation implementation that made this tool possible.

This project is dedicated to his contributions to the WRF community and to the tools that continue to support researchers and forecasters worldwide.

Original project:

```text
https://github.com/JiriRichter/WRFDomainWizard
```

---

## Suggested GitHub Repository Name

```text
wrf-config-studio
```

---

## Suggested GitHub Short Description

```text
Browser-based WRF domain, namelist, WRFDA, OBSPROC, and Registry configuration tool.
```


---

## Documentation Layout

The package documentation has been consolidated for v1.0.0.

Top-level docs now focus on:

- `README.md`
- `QUICK_START.md`
- `USER_GUIDE.md`
- `RELEASE_HISTORY.md`
- `TECHNICAL_REFERENCE.md`
- `PROJECT_LINEAGE.md`

Older individual notes, patch fragments, and source documentation files are preserved in:

```text
docs/archive/legacy_source_docs.zip
```

The NOAA/FSL WRF SI GUI reference PDF is preserved in:

```text
docs/references/WRF_GUI_original_source_69852.pdf
```


---

## Online-Only Map Mode

WRF Config Studio v1.0.0 now uses online map tile providers only. The previous bundled offline vector map fallback has been removed.

The application can still be launched from a local HTTP server, and the editors, metadata catalogs, WPS form, and namelist exports remain local. The map background, however, requires access to one of the online tile providers in the layer selector.


## ARW Context Beta

This beta package adds the ARW Technical Note v4 as a scientific-context source for the namelist editor. The beta context is reference-only and does not change export behavior, compatibility policy, or user control. See `BETA_ARW_CONTEXT_V1.1.0.md`.

