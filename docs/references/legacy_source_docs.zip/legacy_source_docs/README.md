# WRF Config Studio Documentation

Generated: 2026-05-02T04:52:05Z

This `docs/` folder has been consolidated for **WRF Config Studio v1.0.0**.



## ARW Context Beta

This beta package adds the ARW Technical Note v4 as a scientific-context source for the namelist editor. The beta context is reference-only and does not change export behavior, compatibility policy, or user control. See `BETA_ARW_CONTEXT_V1.1.0.md`.


## Top-level documents

- `QUICK_START.md` — shortest path to launch the app and export files.
- `USER_GUIDE.md` — full user guide for v1.0.0.
- `RELEASE_HISTORY.md` — consolidated timestamped release history, changelog, and patch notes.
- `TECHNICAL_REFERENCE.md` — consolidated technical notes, browser compatibility, catalog behavior, export split, Lambert update behavior, and packaging notes.
- `PROJECT_LINEAGE.md` — NOAA/FSL WRF SI GUI lineage, Jiří Richter / WRF Domain Wizard credit, and v1.0.0 rebrand notes.

## Preserved references

- `references/WRF_GUI_original_source_69852.pdf` — historical NOAA/FSL WRF SI GUI reference paper.

## Archived source notes

The former scattered documentation files are preserved as a single archive:

```text
archive/legacy_source_docs.zip
```

That archive contains the individual patch notes, old consolidated files, v3.1 beta supplements, rebrand notes, and other source documentation used to build this consolidated docs folder.

## Current file split behavior

WRF Config Studio v1.0.0 exports:

```text
namelist.wps
namelist.input
namelist.obsproc
```

WRFDA stays in `namelist.input`. OBSPROC saves separately as `namelist.obsproc`.

## Online-only map mode

The previous bundled offline vector map mode has been removed. WRF Config Studio v1.0.0 uses online tile providers only for the map background. The online-only map note is consolidated into `TECHNICAL_REFERENCE.md`.

## Documentation policy

The top-level docs are intended for current users. The archive exists for traceability and historical review.


## Current Docs Manifest

| File | Size bytes | SHA256 short |
|---|---:|---|
| `BETA_ARW_CONTEXT_V1.1.0.md` | 1430 | `a942d15cb38158f0` |
| `MANIFEST.txt` | 534 | `1c5f0e83d403efd0` |
| `PROJECT_LINEAGE.md` | 5824 | `d575a0150367fc6c` |
| `QUICK_START.md` | 977 | `bdb33bb5e225537a` |
| `RELEASE_HISTORY.md` | 229466 | `faeee5d7a245e37c` |
| `TECHNICAL_REFERENCE.md` | 22209 | `50e7977c0c0dbd45` |
| `USER_GUIDE.md` | 20524 | `1eabf28c555e5d46` |
| `archive/README.md` | 465 | `7b04e82751db9743` |
| `archive/legacy_source_docs.zip` | 2793046 | `c76f0fc7d741abb1` |
| `references/WRF_GUI_original_source_69852.pdf` | 1510850 | `5610efd8ce09df6e` |
| `references/v4_technote.pdf` | 2979946 | `981cc9bf7e5428f2` |
